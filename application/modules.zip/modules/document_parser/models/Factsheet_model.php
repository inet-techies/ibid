<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Factsheet_model
 *
 * Dedicated model for managing Tender Fact Sheet records in the single `TenderFactSheet` table.
 * Stores Fact Sheet data according to the 12 main headings in the reference PDF,
 * with one dedicated column per section using a consistent 'Label: Value | Label: Value' separator.
 */
class Factsheet_model extends CI_Model
{
    protected $table = 'TenderFactSheet';

    public function __construct()
    {
        parent::__construct();
        $this->ensureTable();
    }

    /**
     * Ensures the single TenderFactSheet table exists in bid_core_db with all 12 section columns
     */
    public function ensureTable()
    {
        $sql = "CREATE TABLE IF NOT EXISTS `TenderFactSheet` (
          `Tfsid` int(11) NOT NULL AUTO_INCREMENT,
          `Bcid` int(11) DEFAULT NULL,
          `DocumentPath` varchar(255) NOT NULL,
          `DocumentName` varchar(255) NOT NULL,
          `DocumentHash` varchar(64) DEFAULT NULL,
          `TxtFilePath` varchar(255) DEFAULT NULL,
          `Classification` varchar(50) DEFAULT 'unknown',
          `ClassificationStatus` varchar(50) DEFAULT 'unclassified',
          
          -- 12 Main Heading Section Columns (One Column Per Section)
          `TenderOverview` text DEFAULT NULL,
          `ImportantDates` text DEFAULT NULL,
          `TenderValue` text DEFAULT NULL,
          `ScopeOfWork` text DEFAULT NULL,
          `AreasCovered` text DEFAULT NULL,
          `ContractPeriod` text DEFAULT NULL,
          `AwardCriteria` text DEFAULT NULL,
          `PerformanceGuarantee` text DEFAULT NULL,
          `BidValidity` text DEFAULT NULL,
          `Warranty` text DEFAULT NULL,
          `RiskPoints` text DEFAULT NULL,
          `OpportunityAssessment` text DEFAULT NULL,

          -- Legacy Individual Columns (Preserved for compatibility)
          `Department` varchar(255) DEFAULT NULL,
          `ZoneRegion` varchar(255) DEFAULT NULL,
          `TenderTitle` varchar(500) DEFAULT NULL,
          `TenderType` varchar(100) DEFAULT NULL,
          `TenderRefNo` varchar(150) DEFAULT NULL,
          `TenderDate` varchar(100) DEFAULT NULL,
          `ProjectValue` varchar(100) DEFAULT NULL,
          `ProjectValueAmount` decimal(15,2) DEFAULT NULL,
          `ContractType` varchar(100) DEFAULT NULL,
          `WarrantyAmc` varchar(255) DEFAULT NULL,
          `BidSystem` varchar(100) DEFAULT NULL,
          `TenderPublishedDate` varchar(100) DEFAULT NULL,
          `TenderDownloadPeriod` varchar(150) DEFAULT NULL,
          `PreBidQueryDeadline` varchar(100) DEFAULT NULL,
          `PreBidMeeting` varchar(150) DEFAULT NULL,
          `BidSubmissionDeadline` varchar(150) DEFAULT NULL,
          `TechnicalBidOpening` varchar(150) DEFAULT NULL,
          `FinancialBidOpening` varchar(150) DEFAULT NULL,
          `ImportantDatesJson` text DEFAULT NULL,
          `EstimatedValue` varchar(100) DEFAULT NULL,
          `EstimatedValueAmount` decimal(15,2) DEFAULT NULL,
          `EmdAmount` varchar(100) DEFAULT NULL,
          `EmdAmountValue` decimal(15,2) DEFAULT NULL,
          `PbgDetails` varchar(255) DEFAULT NULL,
          `PbgPercentage` decimal(5,2) DEFAULT NULL,
          `BidValidityDays` varchar(100) DEFAULT NULL,
          `ScopeItemsJson` text DEFAULT NULL,
          `AreasCoveredJson` text DEFAULT NULL,
          `ContractInitialDuration` varchar(100) DEFAULT NULL,
          `ContractExtendable` varchar(150) DEFAULT NULL,
          `ContractMaxPeriod` varchar(100) DEFAULT NULL,
          `ContractExtensionConditions` text DEFAULT NULL,
          `AwardEvaluationMethod` varchar(255) DEFAULT NULL,
          `AwardSplitWork` varchar(255) DEFAULT NULL,
          `AwardAllocation` varchar(150) DEFAULT NULL,
          `AwardL2L3Matching` varchar(255) DEFAULT NULL,
          `AwardConditions` text DEFAULT NULL,
          `PbgAmount` varchar(100) DEFAULT NULL,
          `PbgValidity` varchar(200) DEFAULT NULL,
          `PbgSubmissionDeadline` varchar(150) DEFAULT NULL,
          `BidValidityDuration` varchar(100) DEFAULT NULL,
          `WarrantyDuration` varchar(100) DEFAULT NULL,
          `WarrantyTerms` text DEFAULT NULL,
          `WarrantyReplacement` varchar(255) DEFAULT NULL,
          `WarrantyRepair` varchar(255) DEFAULT NULL,
          `WarrantySupport` varchar(255) DEFAULT NULL,
          `AmcTerms` varchar(255) DEFAULT NULL,
          `RiskPointsJson` text DEFAULT NULL,
          `PrebidQueryNotes` text DEFAULT NULL,
          `OpportunityAssessmentJson` text DEFAULT NULL,

          -- Audit & Metadata
          `CreatedBy` int(11) DEFAULT NULL,
          `CreationTs` datetime DEFAULT CURRENT_TIMESTAMP,
          `LastChangeTs` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`Tfsid`),
          KEY `idx_bcid` (`Bcid`),
          KEY `idx_docpath` (`DocumentPath`),
          KEY `idx_dochash` (`DocumentHash`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

        $this->db->query($sql);

        // Ensure 12 section columns exist in existing table
        $sectionColumns = [
            'TenderOverview',
            'ImportantDates',
            'TenderValue',
            'ScopeOfWork',
            'AreasCovered',
            'ContractPeriod',
            'AwardCriteria',
            'PerformanceGuarantee',
            'BidValidity',
            'Warranty',
            'RiskPoints',
            'OpportunityAssessment'
        ];

        foreach ($sectionColumns as $col) {
            if (!$this->db->field_exists($col, $this->table)) {
                $this->db->query("ALTER TABLE `{$this->table}` ADD COLUMN `{$col}` TEXT NULL");
            }
        }
    }

    /**
     * Serializes an associative array of key-value pairs into "Label: Value | Label: Value"
     * Escapes any literal pipe symbols inside values for complete integrity.
     */
    public static function serializeKeyValue(array $items)
    {
        $parts = [];
        foreach ($items as $k => $v) {
            $vStr = trim((string)$v);
            if ($vStr === '') continue;
            $vEsc = str_replace('|', '\|', $vStr);
            $kClean = str_replace([':', '|'], ['-', '/'], trim($k));
            $parts[] = "{$kClean}: {$vEsc}";
        }
        return implode(' | ', $parts);
    }

    /**
     * Deserializes "Label: Value | Label: Value" string back into an associative array
     */
    public static function deserializeKeyValue($raw)
    {
        $out = [];
        if (empty($raw)) return $out;
        $segments = preg_split('/(?<!\\\\)\s*\|\s*/', trim((string)$raw));
        foreach ($segments as $seg) {
            $seg = trim($seg);
            if (empty($seg)) continue;
            $colonPos = strpos($seg, ': ');
            if ($colonPos !== false) {
                $label = trim(substr($seg, 0, $colonPos));
                $val   = trim(substr($seg, $colonPos + 2));
                $val   = str_replace('\|', '|', $val);
                $out[$label] = $val;
            } else {
                $out[] = str_replace('\|', '|', $seg);
            }
        }
        return $out;
    }

    /**
     * Serializes a list of items into "1. Item | 2. Item | 3. Item" or "Item | Item"
     */
    public static function serializeList(array $items, $numbered = true)
    {
        $parts = [];
        $i = 1;
        foreach ($items as $item) {
            $itemStr = trim((string)$item);
            if ($itemStr === '') continue;
            $clean = preg_replace('/^[\s*•\-·∩é╖\x{F0B7}\x{00B7}\.o\d\)]+/u', '', $itemStr);
            $clean = trim($clean);
            if (empty($clean)) continue;
            $itemEsc = str_replace('|', '\|', $clean);
            if ($numbered) {
                $parts[] = "{$i}. {$itemEsc}";
                $i++;
            } else {
                $parts[] = $itemEsc;
            }
        }
        return implode(' | ', $parts);
    }

    /**
     * Deserializes list items from "1. Item | 2. Item" back into a flat array of items
     */
    public static function deserializeList($raw)
    {
        $out = [];
        if (empty($raw)) return $out;
        $segments = preg_split('/(?<!\\\\)\s*\|\s*/', trim((string)$raw));
        foreach ($segments as $seg) {
            $seg = trim($seg);
            if (empty($seg)) continue;
            $clean = preg_replace('/^\d+[\.\)]\s*/', '', $seg);
            $clean = preg_replace('/^[\s*•\-·∩é╖\x{F0B7}\x{00B7}\.o\d\)]+/u', '', $clean);
            $clean = trim(str_replace('\|', '|', $clean));
            if (!empty($clean)) {
                $out[] = $clean;
            }
        }
        return $out;
    }

    /**
     * Converts a structured or attribute-based payload into the 12 main section column format
     */
    public function buildSectionPayload(array $data)
    {
        // 1. TenderOverview
        if (empty($data['TenderOverview'])) {
            $overviewKV = [
                'Department'            => isset($data['Department']) ? $data['Department'] : '',
                'Zone'                  => isset($data['ZoneRegion']) ? $data['ZoneRegion'] : '',
                'Tender Title'          => isset($data['TenderTitle']) ? $data['TenderTitle'] : '',
                'Tender Type'           => isset($data['TenderType']) ? $data['TenderType'] : '',
                'Tender Reference No'   => isset($data['TenderRefNo']) ? $data['TenderRefNo'] : '',
                'Tender Date'           => isset($data['TenderDate']) ? $data['TenderDate'] : '',
                'Project Value'         => isset($data['ProjectValue']) ? $data['ProjectValue'] : (isset($data['EstimatedValue']) ? $data['EstimatedValue'] : ''),
                'Contract Type'         => isset($data['ContractType']) ? $data['ContractType'] : '',
                'Warranty + AMC'        => isset($data['WarrantyAmc']) ? $data['WarrantyAmc'] : '',
                'Bid System'            => isset($data['BidSystem']) ? $data['BidSystem'] : ''
            ];
            $data['TenderOverview'] = self::serializeKeyValue($overviewKV);
        }

        // 2. ImportantDates
        if (empty($data['ImportantDates'])) {
            $datesKV = [];
            if (!empty($data['ImportantDatesJson'])) {
                $arr = json_decode($data['ImportantDatesJson'], true);
                if (is_array($arr)) {
                    foreach ($arr as $d) {
                        if (!empty($d['activity']) && !empty($d['date_text'])) {
                            $datesKV[$d['activity']] = $d['date_text'];
                        }
                    }
                }
            }
            if (empty($datesKV)) {
                if (!empty($data['TenderPublishedDate']))   $datesKV['Tender Published'] = $data['TenderPublishedDate'];
                if (!empty($data['TenderDownloadPeriod']))  $datesKV['Tender Download'] = $data['TenderDownloadPeriod'];
                if (!empty($data['PreBidQueryDeadline']))   $datesKV['Pre-Bid Query Submission'] = $data['PreBidQueryDeadline'];
                if (!empty($data['PreBidMeeting']))          $datesKV['Pre-Bid Meeting'] = $data['PreBidMeeting'];
                if (!empty($data['BidSubmissionDeadline']))  $datesKV['Bid Submission'] = $data['BidSubmissionDeadline'];
                if (!empty($data['TechnicalBidOpening']))    $datesKV['Technical Bid Opening'] = $data['TechnicalBidOpening'];
                if (!empty($data['FinancialBidOpening']))    $datesKV['Financial Bid Opening'] = $data['FinancialBidOpening'];
            }
            $data['ImportantDates'] = self::serializeKeyValue($datesKV);
        }

        // 3. TenderValue
        if (empty($data['TenderValue'])) {
            $valKV = [
                'Estimated Value'               => isset($data['EstimatedValue']) ? $data['EstimatedValue'] : (isset($data['ProjectValue']) ? $data['ProjectValue'] : ''),
                'EMD'                           => isset($data['EmdAmount']) ? $data['EmdAmount'] : '',
                'Performance Bank Guarantee'    => isset($data['PbgDetails']) ? $data['PbgDetails'] : (isset($data['PbgAmount']) ? $data['PbgAmount'] : ''),
                'Bid Validity'                  => isset($data['BidValidityDays']) ? $data['BidValidityDays'] : (isset($data['BidValidityDuration']) ? $data['BidValidityDuration'] : '')
            ];
            $data['TenderValue'] = self::serializeKeyValue($valKV);
        }

        // 4. ScopeOfWork
        if (empty($data['ScopeOfWork']) || strpos($data['ScopeOfWork'], ' | ') === false) {
            $scopesArr = [];
            if (!empty($data['ScopeItemsJson'])) {
                $scopesArr = json_decode($data['ScopeItemsJson'], true);
            }
            if (empty($scopesArr) && !empty($data['ScopeOfWork'])) {
                $scopesArr = preg_split('/[\r\n]+|[•·*∩é╖]|\x{F0B7}|\x{00B7}/u', $data['ScopeOfWork']);
            }
            if (!empty($scopesArr) && is_array($scopesArr)) {
                $data['ScopeOfWork'] = self::serializeList($scopesArr, true);
            }
        }

        // 5. AreasCovered
        if (empty($data['AreasCovered']) || strpos($data['AreasCovered'], ' | ') === false) {
            $areasKV = [];
            if (!empty($data['AreasCoveredJson'])) {
                $arr = json_decode($data['AreasCoveredJson'], true);
                if (is_array($arr)) {
                    foreach ($arr as $a) {
                        if (!empty($a['region']) && !empty($a['coverage'])) {
                            if (strtolower(trim($a['region'])) !== 'region') {
                                $areasKV[$a['region']] = $a['coverage'];
                            }
                        }
                    }
                }
            }
            if (empty($areasKV) && !empty($data['AreasCovered'])) {
                $lines = preg_split('/[\r\n]+/', $data['AreasCovered']);
                foreach ($lines as $ln) {
                    $p = explode(':', $ln, 2);
                    if (count($p) == 2 && strtolower(trim($p[0])) !== 'region') {
                        $areasKV[trim($p[0])] = trim($p[1]);
                    }
                }
            }
            if (!empty($areasKV)) {
                $data['AreasCovered'] = self::serializeKeyValue($areasKV);
            }
        }

        // 6. ContractPeriod
        if (empty($data['ContractPeriod'])) {
            $cpKV = [
                'Initial Contract'      => isset($data['ContractInitialDuration']) ? $data['ContractInitialDuration'] : '',
                'Extendable'            => isset($data['ContractExtendable']) ? $data['ContractExtendable'] : '',
                'Maximum Period'        => isset($data['ContractMaxPeriod']) ? $data['ContractMaxPeriod'] : '',
                'Extension Conditions'  => isset($data['ContractExtensionConditions']) ? $data['ContractExtensionConditions'] : ''
            ];
            $data['ContractPeriod'] = self::serializeKeyValue($cpKV);
        }

        // 7. AwardCriteria
        if (empty($data['AwardCriteria'])) {
            $acKV = [
                'Evaluation Method'     => isset($data['AwardEvaluationMethod']) ? $data['AwardEvaluationMethod'] : '',
                'Split Work'            => isset($data['AwardSplitWork']) ? $data['AwardSplitWork'] : '',
                'Possible Allocation'   => isset($data['AwardAllocation']) ? $data['AwardAllocation'] : '',
                'Matching Requirements' => isset($data['AwardL2L3Matching']) ? $data['AwardL2L3Matching'] : ''
            ];
            $data['AwardCriteria'] = self::serializeKeyValue($acKV);
        }

        // 8. PerformanceGuarantee
        if (empty($data['PerformanceGuarantee'])) {
            $pgKV = [
                'Amount'        => isset($data['PbgAmount']) ? $data['PbgAmount'] : (isset($data['PbgPercentage']) ? $data['PbgPercentage'] . '%' : ''),
                'Validity'      => isset($data['PbgValidity']) ? $data['PbgValidity'] : '',
                'Submission'    => isset($data['PbgSubmissionDeadline']) ? $data['PbgSubmissionDeadline'] : ''
            ];
            $data['PerformanceGuarantee'] = self::serializeKeyValue($pgKV);
        }

        // 9. BidValidity
        if (empty($data['BidValidity'])) {
            $bvKV = [
                'Duration' => isset($data['BidValidityDuration']) ? $data['BidValidityDuration'] : (isset($data['BidValidityDays']) ? $data['BidValidityDays'] : '')
            ];
            $data['BidValidity'] = self::serializeKeyValue($bvKV);
        }

        // 10. Warranty
        if (empty($data['Warranty'])) {
            $wKV = [
                'Scope'         => isset($data['WarrantyAmc']) ? $data['WarrantyAmc'] : '',
                'Terms'         => isset($data['WarrantyTerms']) ? $data['WarrantyTerms'] : '',
                'Replacement'   => isset($data['WarrantyReplacement']) ? $data['WarrantyReplacement'] : '',
                'Repair'        => isset($data['WarrantyRepair']) ? $data['WarrantyRepair'] : '',
                'Support'       => isset($data['WarrantySupport']) ? $data['WarrantySupport'] : '',
                'AMC Terms'     => isset($data['AmcTerms']) ? $data['AmcTerms'] : ''
            ];
            $data['Warranty'] = self::serializeKeyValue($wKV);
        }

        // 11. RiskPoints
        if (empty($data['RiskPoints']) || strpos($data['RiskPoints'], ' | ') === false) {
            $risksArr = [];
            if (!empty($data['RiskPointsJson'])) {
                $risksArr = json_decode($data['RiskPointsJson'], true);
            }
            if (empty($risksArr) && !empty($data['RiskPoints'])) {
                $risksArr = preg_split('/[\r\n]+|[•·*∩é╖]|\x{F0B7}|\x{00B7}/u', $data['RiskPoints']);
            }
            if (!empty($risksArr) && is_array($risksArr)) {
                $data['RiskPoints'] = self::serializeList($risksArr, true);
            }
        }

        // 12. OpportunityAssessment
        if (empty($data['OpportunityAssessment']) || strpos($data['OpportunityAssessment'], ' | ') === false) {
            $oaKV = [];
            if (!empty($data['PrebidQueryNotes'])) {
                $oaKV['Pre-Bid Queries'] = $data['PrebidQueryNotes'];
            }
            if (!empty($data['OpportunityAssessmentJson'])) {
                $arr = json_decode($data['OpportunityAssessmentJson'], true);
                if (is_array($arr)) {
                    $idx = 1;
                    foreach ($arr as $item) {
                        $oaKV["Key Attention Area {$idx}"] = $item;
                        $idx++;
                    }
                }
            }
            if (empty($oaKV) && !empty($data['OpportunityAssessment'])) {
                $oaKV['Assessment'] = $data['OpportunityAssessment'];
            }
            if (!empty($oaKV)) {
                $data['OpportunityAssessment'] = self::serializeKeyValue($oaKV);
            }
        }

        return $data;
    }

    /**
     * Inserts a new Fact Sheet record or updates an existing one when re-processed.
     * Always builds and stores the 12 section columns using transactions.
     *
     * @param array $data Fact Sheet attributes
     * @return int|false The Fact Sheet ID (Tfsid)
     */
    public function saveFactSheet(array $data)
    {
        if (empty($data['DocumentPath']) && empty($data['DocumentName'])) {
            return false;
        }

        // Build the 12 main section column values
        $data = $this->buildSectionPayload($data);

        $existing = null;
        if (!empty($data['DocumentHash'])) {
            $existing = $this->db->get_where($this->table, ['DocumentHash' => $data['DocumentHash']])->row_array();
        }
        if (!$existing && !empty($data['DocumentPath'])) {
            $existing = $this->db->get_where($this->table, ['DocumentPath' => $data['DocumentPath']])->row_array();
        }

        $this->db->trans_start();

        if ($existing) {
            $tfsid = (int)$existing['Tfsid'];
            if (empty($data['Bcid']) && !empty($existing['Bcid'])) {
                $data['Bcid'] = $existing['Bcid'];
            }
            $this->db->where('Tfsid', $tfsid);
            $this->db->update($this->table, $data);
        } else {
            $this->db->insert($this->table, $data);
            $tfsid = (int)$this->db->insert_id();
        }

        $this->db->trans_complete();

        if ($this->db->trans_status() === FALSE) {
            log_message('error', 'Factsheet_model::saveFactSheet database transaction failed.');
            return false;
        }

        return $tfsid;
    }

    /**
     * Retrieves a Fact Sheet by its primary key Tfsid
     */
    public function getFactSheetById($id)
    {
        return $this->db->get_where($this->table, ['Tfsid' => (int)$id])->row_array();
    }

    /**
     * Retrieves a Fact Sheet associated with a Bid creation ID (Bcid)
     */
    public function getFactSheetByBcid($bcid)
    {
        $fs = $this->db->order_by('Tfsid', 'DESC')->get_where($this->table, ['Bcid' => (int)$bcid])->row_array();
        if (!$fs && (int)$bcid > 0) {
            // Check if BidCreationDetails has NASPath, TenderId, or BidTitle matching TenderFactSheet
            $bid = $this->db->get_where('BidCreationDetails', ['Bcid' => (int)$bcid])->row_array();
            if ($bid) {
                if (!empty($bid['NASPath'])) {
                    $fs = $this->db->order_by('Tfsid', 'DESC')->get_where($this->table, ['DocumentPath' => $bid['NASPath']])->row_array();
                }
                if (!$fs && !empty($bid['TenderId'])) {
                    $fs = $this->db->order_by('Tfsid', 'DESC')->get_where($this->table, ['TenderRefNo' => $bid['TenderId']])->row_array();
                }
                if (!$fs && !empty($bid['BidTitle'])) {
                    $fs = $this->db->order_by('Tfsid', 'DESC')->like('TenderTitle', substr($bid['BidTitle'], 0, 30))->get($this->table)->row_array();
                }
                if ($fs) {
                    $this->linkFactSheetToBid($fs['Tfsid'], $bcid);
                }
            }
        }
        if (!$fs) {
            $fs = $this->db->order_by('Tfsid', 'DESC')->get($this->table, 1)->row_array();
        }
        return $fs;
    }

    /**
     * Retrieves a Fact Sheet by relative document path
     */
    public function getFactSheetByDocPath($path)
    {
        return $this->db->order_by('Tfsid', 'DESC')->get_where($this->table, ['DocumentPath' => $path])->row_array();
    }

    /**
     * Links a Fact Sheet to a created Bid (Bcid)
     */
    public function linkFactSheetToBid($tfsid, $bcid)
    {
        return $this->db->where('Tfsid', (int)$tfsid)->update($this->table, ['Bcid' => (int)$bcid]);
    }
}
